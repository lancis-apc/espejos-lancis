fv_carreteras_locales_yuc.tif : función de valor de dDistancia a carreteras locales
fv_distancia_costa_yuc_n.tif : función de valor de dDistancia a la línea de playa
fv_distancia_merida_cancun.tif : función de valor de Distancia a las carreteras principales
fv_playa_yuc_n.tif : función de valor de distancia a localidades costeras, excluyendo a la localidad Progreso
fv_progreso_yuc_n.tif : función de valor de distancia a la localidad Progreso
fv_puerto_cs_yuc_n.tif : función de valor de distancia a puertos que cuentan con santuario.
fv_puerto_ss_yuc_n.tif : función de valor de distancia a puertos que no cuentan con santuario.